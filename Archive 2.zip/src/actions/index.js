import { fetchYears, fetchBudgets, putBudget } from "./budgetActions";

export default {
  fetchYears,
  fetchBudgets,
  putBudget
};
