import {
  FETCH_YEAR,
  FETCH_YEAR_SUCCESS,
  FETCH_YEAR_ERROR,
  FETCH_BUDGETS,
  FETCH_BUDGETS_SUCCESS,
  FETCH_BUDGETS_ERROR,
  PUT_BUDGETS,
  PUT_BUDGETS_SUCCESS,
  PUT_BUDGETS_ERROR
} from "../constants/actionTypes";

const url =
  "http://documentracker.tymecoach-development-ase.p.azurewebsites.net/api/";

const action = (type, payload = null) => ({
  type,
  payload
});

export function fetchYears() {
  return dispatch => {
    dispatch(action(FETCH_YEAR));
    fetch(`${url}/Budgets/financialyears`)
      .then(res => res.json())
      .then(json => dispatch(action(FETCH_YEAR_SUCCESS, json)))
      .catch(err => dispatch(action(FETCH_YEAR_ERROR, err)));
  };
}

export function fetchBudgets(year) {
  return dispatch => {
    dispatch(action(FETCH_BUDGETS));
    fetch(`${url}/Budgets`)
      .then(res => res.json())
      .then(json => dispatch(action(FETCH_BUDGETS_SUCCESS, json)))
      .catch(err => dispatch(action(FETCH_BUDGETS_ERROR, err)));
  };
}

export function putBudget(id, data) {
  return dispatch => {
    dispatch(action(PUT_BUDGETS));
    fetch(`${url}/Budgets/${id}`, {
      method: "put",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    })
      .then(res => res.json())
      .then(json => dispatch(action(PUT_BUDGETS_SUCCESS, json)))
      .catch(err => dispatch(action(PUT_BUDGETS_ERROR, err)));
  };
}
