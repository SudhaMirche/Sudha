import {
  FETCH_BUDGETS,
  FETCH_BUDGETS_SUCCESS,
  FETCH_BUDGETS_ERROR
} from "../constants/actionTypes";

const initialState = {
  loading: false,
  data: null,
  error: null
};

export default (state = initialState, action) => {
  switch (action.type) {
    case FETCH_BUDGETS:
      return { ...state, loading: true };

    case FETCH_BUDGETS_SUCCESS:
      return { ...state, loading: false, data: action.payload };

    case FETCH_BUDGETS_ERROR:
      return { ...state, loading: false, error: action.payload };

    default:
      return state;
  }
};
