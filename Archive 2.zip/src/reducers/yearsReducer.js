import {
  FETCH_YEAR,
  FETCH_YEAR_SUCCESS,
  FETCH_YEAR_ERROR
} from "../constants/actionTypes";

const initialState = {
  loading: false,
  data: null,
  error: null
};

export default (state = initialState, action) => {
  switch (action.type) {
    case FETCH_YEAR:
      return { ...state, loading: true };

    case FETCH_YEAR_SUCCESS:
      return { ...state, loading: false, data: action.payload };

    case FETCH_YEAR_ERROR:
      return { ...state, loading: false, error: action.payload };

    default:
      return state;
  }
};
